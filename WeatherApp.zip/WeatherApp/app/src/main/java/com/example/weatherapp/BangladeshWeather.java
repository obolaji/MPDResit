package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class BangladeshWeather extends AppCompatActivity {

    ListView bangladesh;
    ArrayList<String> bangladeshtitles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bangladesh_weather);

        bangladesh= (ListView) findViewById(R.id.bangladesh);
        bangladeshtitles = new ArrayList<String>();
        bangladesh.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });
        new BangladeshWeather.runningBackground().execute();

    }
    public InputStream getInputStream(URL bangladeshUrl)
    {
        try{
            return bangladeshUrl.openConnection().getInputStream();

        }
        catch(IOException e)
        {
            return null;
        }
    }
    public class runningBackground extends AsyncTask<Integer,Void,Exception> {
        Exception exception = null;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Exception doInBackground(Integer... integers) {
            try{
                URL bangladeshUrl = new URL("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/1185241");

                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(false);

                XmlPullParser exp = factory.newPullParser();
                exp.setInput(getInputStream(bangladeshUrl), "UTF_8");
                boolean insideItem= false;
                int eventType = exp.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT)
                {
                    if (eventType== XmlPullParser.START_TAG)
                    {
                        if (exp.getName().equalsIgnoreCase("item"))
                        {
                            insideItem = true;
                        }
                        else if (exp.getName().equalsIgnoreCase("title"))
                        {
                            if (insideItem)
                            {
                                bangladeshtitles.add(exp.nextText());
                            }
                        }
                    }else if (eventType == XmlPullParser.END_TAG && exp.getName().equalsIgnoreCase("item"))
                    {
                        insideItem = false;
                    }
                    eventType = exp.next();
                }



            }catch(MalformedURLException e)
            {
                exception=e;
            }
            catch(XmlPullParserException e){
                exception =e;
            } catch (IOException e) {
                exception = e;
            }
            return exception;
        }
        @Override
        protected void onPostExecute(Exception s){
            super.onPostExecute(s);;

            ArrayAdapter<String> bangladeshAdapter = new ArrayAdapter<String>(BangladeshWeather.this, android.R.layout.simple_list_item_1, bangladeshtitles);

            bangladesh.setAdapter(bangladeshAdapter);
        }


    }


}




