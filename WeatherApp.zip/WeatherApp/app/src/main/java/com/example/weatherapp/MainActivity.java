package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.LinkedList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private TextView glasgow;
    private TextView london;
    private TextView newyork;
    private TextView oman;
    private TextView mauritius;
    private TextView bangladesh;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        glasgow = (TextView) findViewById(R.id.glasgow);
        london = (TextView) findViewById(R.id.london);
        newyork = (TextView) findViewById(R.id.newyork);
        oman = (TextView) findViewById(R.id.oman);
        mauritius = (TextView) findViewById(R.id.mauritius);
        bangladesh = (TextView) findViewById(R.id.bangladesh);

        glasgow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, GlasgowWeather.class);
                startActivity(intent);

            }
        });

        london.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LondonWeather.class);
                startActivity(intent);

            }
        });

        newyork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NewYorkWeather.class);
                startActivity(intent);

            }
        });

        oman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, OmanWeather.class);
                startActivity(intent);

            }
        });

        mauritius.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MauritiusWeather.class);
                startActivity(intent);

            }
        });

        bangladesh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, BangladeshWeather.class);
                startActivity(intent);

            }
        });


    }

}

