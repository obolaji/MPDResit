package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

public class LondonWeather extends AppCompatActivity {
    ListView london;
    ArrayList<String> titles;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_london_weather);

        london = (ListView) findViewById(R.id.london);
        titles = new ArrayList<String>();
        london.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });
        new runningBackground().execute();

        }
public InputStream getInputStream(URL londonUrl)
{
    try{
        return londonUrl.openConnection().getInputStream();

    }
catch(IOException e)
{
 return null;
}
    }
public class runningBackground extends AsyncTask<Integer,Void,Exception> {
        Exception exception = null;
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected Exception doInBackground(Integer... integers) {
        try{
            URL londonUrl = new URL("https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/2643743");

            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(false);

            XmlPullParser exp = factory.newPullParser();
            exp.setInput(getInputStream(londonUrl), "UTF_8");
            boolean insideItem= false;
            int eventType = exp.getEventType();

            while (eventType != XmlPullParser.END_DOCUMENT)
            {
                if (eventType== XmlPullParser.START_TAG)
                {
                    if (exp.getName().equalsIgnoreCase("item"))
                    {
                        insideItem = true;
                    }
                    else if (exp.getName().equalsIgnoreCase("title"))
                    {
                        if (insideItem)
                        {
                            titles.add(exp.nextText());
                        }
                    }
                }else if (eventType == XmlPullParser.END_TAG && exp.getName().equalsIgnoreCase("item"))
                {
                    insideItem = false;
                }
                eventType = exp.next();
            }



        }catch(MalformedURLException e)
        {
            exception=e;
        }
        catch(XmlPullParserException e){
            exception =e;
        } catch (IOException e) {
            exception = e;
        }
        return exception;
    }
 @Override
    protected void onPostExecute(Exception s){
        super.onPostExecute(s);;

        ArrayAdapter<String> londonAdapter = new ArrayAdapter<String>(LondonWeather.this, android.R.layout.simple_list_item_1, titles);

        london.setAdapter(londonAdapter);
 }


}


}